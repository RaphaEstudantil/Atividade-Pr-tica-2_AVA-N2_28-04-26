import express from 'express';
import {
    getClientes, getProdutos,
    postCliente,
    putCliente,
    deleteCliente
} from './controller/controller.js';

const app = express();
app.use(express.json()); // Middleware para parsear JSON

app.get('/clientes', async (req, res) => {
    try {
        // No Express, as Query Strings já vêm prontas dentro de 'req.query'
        const bairro = req.query.bairro;
        const clientes = await getClientes(bairro);

        // res.json() já define o Header e converte para string automaticamente!
        res.json(clientes);
    } catch (erro) {
        res.status(500).json({ erro: "Erro interno no servidor" });
        console.error("Erro ao buscar clientes:", erro);
    }
});

// POST /clientes
app.post('/clientes', async (req, res) => {
    try {
        //Validação básica (OC 546)
        if (!req.body.nome) {
            return res.status(400).json({ erro: "O nome do cliente é obrigatório!" });
        }

        // Os dados chegam perfeitos em req.body graças ao express.json()
        const novoCliente = await postCliente(req.body);
        res.status(201).json({ mensagem: "Sucesso!", cliente: novoCliente });
    } catch (erro) {
        res.status(400).json({ erro: "Dados inválidos" });
        console.log("Erro ao cadastrar cliente:", erro);
    }
});

// ====================================================
// 🔵 ROTAS DINÂMICAS COM PARÂMETROS (O Fim do split('/'))
// ====================================================

// O Express usa os dois pontos ( : ) para avisar que aquele pedaço da URL é uma variável
app.put('/clientes/:id', async (req, res) => {
    try {
        // Ele extrai o ID da URL automaticamente e coloca em 'req.params'
        const id = req.params.id;

        const atualizado = await putCliente(id, req.body);
        if (!atualizado) {
            return res.status(404).json({ erro: "Cliente não encontrado" });
        }

        res.json({ mensagem: "Atualizado com sucesso", cliente: atualizado });
    } catch (erro) {
        res.status(500).json({ erro: "Erro ao atualizar" });
    }
});

// DELETE /clientes/:id
app.delete('/clientes/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const excluido = await deleteCliente(id);

        if (!excluido) {
            return res.status(404).json({ erro: "Cliente não encontrado" });
        }
        res.json({ mensagem: "Cliente excluído com sucesso" });
    } catch (erro) {
        res.status(500).json({ erro: "Erro ao deletar" });
        console.error("Erro ao excluir cliente:", erro);
    }
});

// Ligar o servidor
app.listen(3000, () => {
    console.log("🚀 Servidor EXPRESS rodando na porta 3000!");
});